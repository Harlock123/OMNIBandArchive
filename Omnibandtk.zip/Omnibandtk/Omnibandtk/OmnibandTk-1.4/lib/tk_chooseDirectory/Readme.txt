This package provides a replacement tk_chooseDirectory command that
does not bomb on Win95. To use it:

% load tk_chooseDirectory.dll

