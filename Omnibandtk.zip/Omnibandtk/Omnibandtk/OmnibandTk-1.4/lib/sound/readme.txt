Readme.txt for Grundman's Z/AngbandtK Ultimate Sound File

6/15/99
These are the 'repaired' sound files I posted after the original upload (approx 6/10/99). I
mistakenly included the WRONG tk sound configuration file. Note I have included both the
angbandtK AND the ZangbandtK sound file, install as explained below with ONE important
exception!! The zangbandtk config file is called 'zsound'. You MUST remove the letter z 
from the file before installing or it will not work. I apologize for the inconvienence
to all!)

There are a total of four sound files, titled 'sound1.zip' 'sound2.zip' 'sound3.zip'
and 'sound4.zip'. Each is approx. 2.5 megs zipped. They are in .wav format,
and I've included the sound configuration file required to assign them within
the game to the tk format that Tim Bakers version of Zang/AngbandtK requires.
You should only have to copy the 'sound'file over your existing one to get these
wav files to be in the sound trigger spots I assigned (very important!).
This directory is located in: [zangbandtK/angbandtK]/tk/config.

Important Note! Do not distribute any of these files commercially as many of them are
copywrited. These files are for your own personal use ONLY.

Enjoy!

Grundman