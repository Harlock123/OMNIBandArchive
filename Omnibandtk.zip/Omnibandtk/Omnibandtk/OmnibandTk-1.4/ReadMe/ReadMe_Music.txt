About Music
===========

OmnibandTk uses the BASS audio library to play music. BASS is free for
non-commercial use. Visit http://www.un4seen.com/music/ for details.

BASS requires DirectX 3 or above, so it not only works with Windows
95/98/ME/2000, but also Windows NT 4.0 (with service pack 4). BASS does
not require that a soundcard with DirectSound/DirectSound3D hardware
accelerated drivers is installed, but it does improve performance if
there is one. BASS also takes advantage of MMX acceleration, which
improves the performance of the MOD music playback.

BASS plays MOD files in the following formats:

	Protracker (.mod)
	Scream Tracker 3 (.s3m)
	FastTracker 2 (.xm)
	Impulse Tracker (.it)
	Something else (.mtm)

=====

Tim Baker
Email: dbaker@direct.ca
August 4, 2001

