OmnibandTk Sound System
======================

There are a few DLL files which allow OmnibandTk to make noise.

BASS
----
One of the DLLs uses the BASS audio library (the same library
used for music). This requires DirectX 3 or above. Try this one
first if you have DirectSound installed. It should work on
Windows NT 4.0 (with service pack 4).

DirectSound
-----------
One of the DLLs uses Microsoft's DirectSound technology (part of
DirectX) to make noise. It is very low-latency (fast) and plays
sounds at whatever frequency they were recorded at. This DLL is
called "sound-directsound.dll".

Microsoft's WaveMix
-------------------
One of the DLLs contains a slightly changed version of Microsoft's
WaveMix DLL. This is a very high-latency (sloooow) noisemaker
which plays sounds at 11KHz only. This DLL is called "sound-wavemix.dll".

No Sound Card
-------------

If your computer does not have a sound card then you will probably
get an error using one of the other DLL files. The sound-nocard.dll
file is a dummy DLL that does not use the computer's sound system.

Configuring Sound
=================

Click the Setup button when the program first starts. This will display
the Setup Window which allows you to configure some things such as the
icon set, music and sound.

=====

Tim Baker
Email: dbaker@direct.ca
August 4, 2001



