About the Graphics in ZAngbandTk
================================

The graphics in the following files are by Adam Bolt, and are used
with his permission:

	adam16.gif, adam16_feature.gif

The adam16_feature.gif file includes an incredible mountain/hill image
created by M�rten Woxberg.

=====

The graphics in the tk\image\dg directory are by David E. Gervais,
and are used with his permission.

=====

The "Tcl Powered Logo" image in the file pwrdLogo175.gif is used
in accordance with the README file in the lib\tk\images directory
included with the Tk distribution.

=====

Tim Baker
Email: dbaker@direct.ca
October 14, 1999
