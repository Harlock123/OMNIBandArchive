About the Graphics in AngbandTk
===============================

The graphics in the following files are by Adam Bolt, and are used
with his permission:

	adam16.gif, adam16_feature.gif

The adam16_feature.gif file includes an incredible mountain/hill image
created by M�rten Woxberg.

=====

The graphics in the tk\image\dg directory are by David E. Gervais,
and are used with his permission.

=====

The graphics in the following files are based on the work of various
artists and are used without their permission. In these cases, a
section of an original work may have been cropped, scaled, converted
to 256 colors, and/or had other image manipulations performed on it
(such as adjusting brightness, contrast, and so on) for inclusion in
this game:

	dragon.gif
	masked.gif
	unmasked.gif
	
If you are a person responsible for the work(s) that served as the
source for the graphics described above, and if you decide that the
use of these graphics conflicts with your interests, then contact
Tim Baker (dbaker@direct.ca) and he will be happy to rectify the
situation to your complete satisfaction.

=====

The "Tcl Powered Logo" image in the file pwrdLogo175.gif is used
in accordance with the README file in the lib\tk\images directory
included with the Tk distribution.

=====

Tim Baker
Email: dbaker@direct.ca
October 23, 1999

