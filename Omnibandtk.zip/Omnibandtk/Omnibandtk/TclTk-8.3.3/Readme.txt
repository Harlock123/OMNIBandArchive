This is a minimal version of Tcl and Tk for use with AngbandTk.

-- Tim Baker
